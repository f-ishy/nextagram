import React from 'react';
import './App.css';
import axios from 'axios';
import Loading from './components/loading';
import Home from './pages/home';
import 'bootstrap/dist/css/bootstrap.css';


class App extends React.Component {
  state = {
    isLoading : true,
    users: []
  }

  componentDidMount(){
    axios.get(`https://insta.nextacademy.com/api/v1/users/`)
      .then((response) => {
        console.log(response);
        this.setState({users : response.data, isLoading : false})
      })
      .catch((error) => {
        console.log(error);
      })
  }


  render(){
    return (this.state.isLoading)
    ? <Loading/>
    : <Home users={this.state.users}/>
  }
}

export default App;
