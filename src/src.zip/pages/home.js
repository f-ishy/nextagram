import React, {Component} from 'react';
import logo from '../logo.png';
import 'bootstrap/dist/css/bootstrap.css';
import UserImages from '../containers/userimages';
import {
    Container,
    Row,
    Col,
    Navbar,
    NavbarBrand} from 'reactstrap';

class Home extends Component {
    constructor(props){
        super(props)
        this.state={}
    }

    render(){
        return(
            <>
                <Navbar color="light">
                    <div>
                        <img src={logo} width='40px' style={{ marginLeft: '15px', marginRight: '15px' }} alt=""></img>
                        <NavbarBrand>Home Page</NavbarBrand>
                    </div>
                </Navbar>
                <ul style={{padding:'0'}}>
                    {this.props.users.map(user =>
                            <Container fluid>
                                <Row style={{border: '2px solid black', backgroundColor: 'rgba(0,0,0,0.2' }}>
                                    <Col md="3" style={{ borderRight: '2px solid black', textAlign: 'center'}}>
                                        {/* <li key={user.id} style={{listStyleType: 'none', textAlign: 'center' }}> */}
                                            <img src={user.profileImage} style={{width: '150px', height: '150px', objectFit:'cover', borderRadius: '50%', marginTop:'20px', marginBottom:'20px'}} alt=""></img>
                                            <p style={{}}>{user.id}: {user.username}</p>
                                        {/* </li> */}
                                    </Col>
                                    <Col md="9">
                                        <Container fluid>
                                            <UserImages height = '300px' width = '400px' user_id={user.id}/>
                                            {/* <UserImages user_id={user.id}/> */}
                                        </Container>
                                    </Col>
                                </Row>
                            </Container>
                        )
                    }
                </ul>
            </>
        )
    }
}

export default Home